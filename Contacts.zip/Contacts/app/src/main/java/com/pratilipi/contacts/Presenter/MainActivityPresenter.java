package com.pratilipi.contacts.Presenter;

public class MainActivityPresenter {

}
